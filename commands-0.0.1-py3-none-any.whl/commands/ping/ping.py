def pingTBS():
    return b'\xc8\x04(\x00\x0e|'